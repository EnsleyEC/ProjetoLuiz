/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceserial;

/**
 *
 * @author Usuário
 */
public class Protocolo {
    private String estado;
    
    private String leituraComando;
    
    private void interpretaComando(){
        estado = leituraComando;
    }

    public String getLeituraComando() {
        return leituraComando;
    }

    public void setLeituraComando(String leituraComando) {
        this.leituraComando = leituraComando;
        this.interpretaComando();
    }
    
   
}
