/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaceserial;

import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Enumeration;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;

/**
 *
 * @author Usuário
 */
public class RxTx implements SerialPortEventListener {

    SerialPort serialPort = null;
    
    private JLabel estado;
    private JProgressBar progresso;

    private Protocolo protocolo = new Protocolo();  //Gestão dos valores enviados na serial
    private String appName; //Nome da aplicação

    private BufferedReader br;  //Leitor serial
    private OutputStream os;    //Escritor serial

    private final int TIME_OUT = 1000;      //Tempo de espera
    private int BAUD_RATE;    //Velocidade da comunicação
    private int delay;

    private String serialPortName;
    
    public RxTx(JLabel estado, JProgressBar progresso){
        this.estado = estado;
        this.progresso = progresso;
    }

    public boolean iniciaSerial(String port, int velocidade) {        
        boolean status = false;
        serialPortName = port;
        BAUD_RATE = velocidade;
        
        try {
            //Pega todas as portas seriais
            CommPortIdentifier portId = null;
            Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

            while (portId == null && portEnum.hasMoreElements()) {
                CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();

                if (currPortId.getName().equals(serialPortName) || currPortId.getName().startsWith(serialPortName)) {
                    serialPort = (SerialPort) currPortId.open(appName, TIME_OUT);
                    portId = currPortId;
                    JOptionPane.showMessageDialog(null, "Conectado com sucesso!\n "
                            + "Porta atual: " + serialPortName);
                }
            }

            if (portId == null || serialPort == null) {
                return false;
            }
            
            serialPort.setSerialPortParams(BAUD_RATE, SerialPort.DATABITS_8, 
                    SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
            
            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
            status = true;
            
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                status = false;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao conectar com a porta "+serialPortName);
        }
        return status;
    }
    
    public void enviarDado(String dado){
        try {
            os = serialPort.getOutputStream();
            os.write(dado.getBytes());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao enviar comando");
        }
    }

    public synchronized void encerraSerial(){
        if(serialPort != null){
            serialPort.removeEventListener();
            serialPort.close();
        }
    }
    
    @Override
    public void serialEvent(SerialPortEvent spe) {
        try {
            switch(spe.getEventType()){
                case SerialPortEvent.DATA_AVAILABLE:
                    if(br == null){
                        br = new BufferedReader(
                            new InputStreamReader(
                            serialPort.getInputStream()));
                        
                    }         
                    
                    //Aqui são tratadas todas as informações que chegam do MCU
                    if(br.ready()){
                        protocolo.setLeituraComando(br.readLine());
                        String comando = protocolo.getLeituraComando();
                                                
                        if(comando.startsWith("Estado: ")){
                            estado.setText(comando.substring(8));
                            progresso.setEnabled(false);
                            progresso.setStringPainted(false);
                        }
                        
                        if(comando.startsWith("Erro: ")){
                            JOptionPane.showMessageDialog(null, comando.substring(6));
                            progresso.setEnabled(false);
                            progresso.setStringPainted(false);
                        }
                        
                        if(comando.startsWith("Delay: ")){
                           delay = Integer.parseInt(comando.substring(7));
                           progresso.setStringPainted(true);   
                           JOptionPane.showMessageDialog(null, "Usuário Bloqueado!");                                                   
                        }
                        
                        if(comando.startsWith("Tempo: ")){
                            int tempo = Integer.parseInt(comando.substring(7));
                            tempo = (tempo*100)/delay;                            
                            progresso.setEnabled(true);                            
                            progresso.setValue(tempo);
                            progresso.setString("Reiniciando sistema... ("+tempo+"%)");
                        }                        
                    }
                    break;
            
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
